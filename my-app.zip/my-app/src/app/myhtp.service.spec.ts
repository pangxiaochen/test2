import { TestBed, inject } from '@angular/core/testing';

import { MyhtpService } from './myhtp.service';

describe('MyhtpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyhtpService]
    });
  });

  it('should be created', inject([MyhtpService], (service: MyhtpService) => {
    expect(service).toBeTruthy();
  }));
});
