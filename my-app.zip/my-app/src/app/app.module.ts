import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from "@angular/common/http";
import {CxpRouteModule} from "./common/route/cxp-route/cxp-route.module";
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HtpCltComponent } from './htp/htp-clt/htp-clt.component';


import {MyhtpService} from "./myhtp.service";
import { VideoPanelComponent } from './main-panel/video-panel/video-panel.component';
import { ChildNavPanelComponent } from './main-panel/child-nav-panel/child-nav-panel.component';

import {TooltipModule,AlertModule,ModalModule} from "ngx-bootstrap";
import { MyModalPanelTestComponent } from './main-panel/my-modal-panel-test/my-modal-panel-test.component';
import { MyModalMoreTestComponent } from './main-panel/my-modal-more-test/my-modal-more-test.component';
import { MyModalClidTestComponent } from './main-panel/my-modal-clid-test/my-modal-clid-test.component';
import { HighlightDirective } from './mytest/highlight.directive';
import { UnlessDirective } from './mytest/unless.directive';
import { MydirectiveComponent } from './mytest/mydirective/mydirective.component';
import { MypipePipe } from './mytest/mypipe.pipe';
import { FilmPanelComponent } from './film/film-panel/film-panel.component';
import { TvPanelComponent } from './tv/tv-panel/tv-panel.component';
import { WheelPlantingComponent } from './widget/wheel-planting/wheel-planting.component';
import { SearchComponent } from './widget/search/search.component';
import { VedioComponent } from './vedio/vedio/vedio.component';



@NgModule({
  declarations: [
    AppComponent,
    HtpCltComponent,
    VideoPanelComponent,
    ChildNavPanelComponent,
    MyModalPanelTestComponent,
    MyModalMoreTestComponent,
    MyModalClidTestComponent,
    HighlightDirective,
    UnlessDirective,
    MydirectiveComponent,
    MypipePipe,
    FilmPanelComponent,
    TvPanelComponent,
    WheelPlantingComponent,
    SearchComponent,
    VedioComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CxpRouteModule,
    FormsModule,
    TooltipModule.forRoot(),
    AlertModule.forRoot(),
    ModalModule.forRoot(),

  ],
  providers: [
    MyhtpService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
