import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtpCltComponent } from './htp-clt.component';

describe('HtpCltComponent', () => {
  let component: HtpCltComponent;
  let fixture: ComponentFixture<HtpCltComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtpCltComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtpCltComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
