import { Component, OnInit } from '@angular/core';
import {MyhtpService} from "../../myhtp.service";
@Component({
  selector: 'app-htp-clt',
  templateUrl: './htp-clt.component.html',
  styleUrls: ['./htp-clt.component.css']
})
export class HtpCltComponent implements OnInit {
  config:any;
  constructor(private  myServe:MyhtpService) {

  }

  ngOnInit() {

    this.showJson();
    console.log(this.config);

  }
  showJson(){
    this.myServe.getConfigJson().subscribe((data) => {
     console.log(data);
      debugger;
    });
  }
}
