import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-panel',
  templateUrl: './film-panel.component.html',
  styleUrls: ['./film-panel.component.css']
})
export class FilmPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
