import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {VideoPanelComponent} from "../../../main-panel/video-panel/video-panel.component";
import {FilmPanelComponent} from "../../../film/film-panel/film-panel.component";
import {TvPanelComponent} from "../../../tv/tv-panel/tv-panel.component";
import {VedioComponent} from "../../../vedio/vedio/vedio.component";

const appRoutes: Routes = [
  { path: '', component:VideoPanelComponent},
  {'path':'cxp/tv',component:TvPanelComponent},
  {'path':'cxp/film',component:FilmPanelComponent},
  {'path':'cxp/video/:id',component:VedioComponent},
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes,{ useHash: true })
  ],
  declarations: [],
  exports:[RouterModule]
})
export class CxpRouteModule { }
