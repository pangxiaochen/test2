import { TestBed, inject } from '@angular/core/testing';

import { YoghourtService } from './yoghourt.service';

describe('YoghourtService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [YoghourtService]
    });
  });

  it('should be created', inject([YoghourtService], (service: YoghourtService) => {
    expect(service).toBeTruthy();
  }));
});
