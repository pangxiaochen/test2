import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {HttpClientModule} from "@angular/common/http";

@Injectable()
export class YoghourtService {
  //获取配置文件信息
   path:string="";
  constructor(private htp:HttpClient) { }
  getLocation(){}
}
