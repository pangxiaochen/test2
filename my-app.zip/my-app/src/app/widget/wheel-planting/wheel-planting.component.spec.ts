import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WheelPlantingComponent } from './wheel-planting.component';

describe('WheelPlantingComponent', () => {
  let component: WheelPlantingComponent;
  let fixture: ComponentFixture<WheelPlantingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WheelPlantingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WheelPlantingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
