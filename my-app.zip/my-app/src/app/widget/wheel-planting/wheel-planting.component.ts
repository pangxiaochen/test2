import { Component, OnInit,Input} from '@angular/core';

@Component({
  selector: 'app-wheel-planting',
  templateUrl: './wheel-planting.component.html',
  styleUrls: ['./wheel-planting.component.css']
})
export class WheelPlantingComponent implements OnInit {
   @Input() data:any;
  constructor() { }

  ngOnInit() {
  }

}
