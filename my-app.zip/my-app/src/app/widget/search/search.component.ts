import { Component, OnInit } from '@angular/core';
import {isUndefined} from "util";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchMap:any=[];
  hotList:any=[];
  search:string="";
  isHotList:boolean=false;
  isSearchList:boolean=false;
  initIndx:number=0;
  constructor() { }

  ngOnInit() {
    this.hotList=[
      {"label":"奇葩说","path":""},
      {"label":"东北一家人","path":""},
      {"label":"奥特曼","path":""},
      {"label":"狮子王","path":""},
      {"label":"西红柿首富","path":""},
      {"label":"邪不压正","path":""},
      {"label":"舌尖上的中国","path":""},
      {"label":"笑傲江湖","path":""},
      {"label":"倾城之恋","path":""},
      {"label":"妻子的旅行","path":""},
    ];
  }
  commonSearch($event){

  }
  searchToggle($event){
     let searchkey=this.search;
     if(searchkey.length==0){
        this.isHotList=true;
        this.isSearchList=false;
     }else{
       this.isHotList=false;
       this.isSearchList=true;
     }
  }
  hideList(){
    this.isHotList=false;
    this.isSearchList=false;
    this.initIndx=0;
  }
  searchCtl(key){
    let codeNum=key.keyCode;
    if(isUndefined(codeNum)){
      return;
    }
    switch (codeNum){
      case 40:this.down();
        console.log(codeNum);
      break;
      case 38:this.up();
        console.log(codeNum);
      break;
      case 13:this.goSearch();
      break;
      default:
        this.keyOther();
        break;
    }
  }
  down(){
    this.initIndx++;
    if(this.initIndx>9){
      this.initIndx=0;
    }
    this.search=this.hotList[this.initIndx].label;
  }
  up(){
    this.initIndx--;
    if(this.initIndx<0){
      this.initIndx=9;
    }
    this.search=this.hotList[this.initIndx].label;
  }
  keyOther(){
    this.isHotList=false;
    this.isSearchList=true;
    if(this.search==""){
      this.isHotList=true;
      this.isSearchList=false;
    }
  }
  goSearch(){

  }
}
