import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildNavPanelComponent } from './child-nav-panel.component';

describe('ChildNavPanelComponent', () => {
  let component: ChildNavPanelComponent;
  let fixture: ComponentFixture<ChildNavPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildNavPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildNavPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
