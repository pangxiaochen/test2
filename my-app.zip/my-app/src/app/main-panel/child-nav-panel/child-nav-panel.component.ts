import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child-nav-panel',
  templateUrl: './child-nav-panel.component.html',
  styleUrls: ['./child-nav-panel.component.css']
})
export class ChildNavPanelComponent implements OnInit {
   childItems:any;
   type:any=[];
  constructor() { }
  ngOnInit() {
    function Type(label,path){
      this.label=label;
      this.path=path;
    }
    this.childItems=["内地","香港","台湾"];
    this.type=[
      {"typeName":"tv","typeVal":[
        new Type("电视剧","tv"),
        new Type("电影","film"),
        new Type("娱乐",""),
        new Type("综艺",""),
        new Type("资讯",""),
        new Type("网络电影",""),
        new Type("片花",""),
        new Type("脱口秀",""),
        ]},
      {"typeName":"original","typeVal":[
        new Type("动漫",""),
        new Type("搞笑",""),
        new Type("音乐",""),
        new Type("原创",""),
        new Type("游戏",""),
       new Type("旅游",""),
       new Type("时尚",""),
       new Type("拍客",""),
      ]},
      {"typeName":"finance","typeVal":[
        new Type("财经",""),
        new Type("搞笑",""),
        new Type("体育",""),
        new Type("儿童",""),
        new Type("生活",""),
        new Type("军事",""),
        new Type("公益",""),
        new Type("文学",""),
      ]},
      {"typeName":"hotspot","typeVal":[
        new Type("热点",""),
        new Type("全国影视",""),
        new Type("直播",""),
        new Type("商城",""),
        new Type("大头",""),
        new Type("风云榜",""),
        new Type("应用商店",""),
        new Type("VR",""),
      ]},


    ]
  }

}
