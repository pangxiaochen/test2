import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalPanelTestComponent } from './my-modal-panel-test.component';

describe('MyModalPanelTestComponent', () => {
  let component: MyModalPanelTestComponent;
  let fixture: ComponentFixture<MyModalPanelTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyModalPanelTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalPanelTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
