import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalClidTestComponent } from './my-modal-clid-test.component';

describe('MyModalClidTestComponent', () => {
  let component: MyModalClidTestComponent;
  let fixture: ComponentFixture<MyModalClidTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyModalClidTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalClidTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
