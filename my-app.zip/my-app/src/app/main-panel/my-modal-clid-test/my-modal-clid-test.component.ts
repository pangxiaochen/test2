import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-modal-clid-test',
  templateUrl: './my-modal-clid-test.component.html',
  styleUrls: ['./my-modal-clid-test.component.css']
})
export class MyModalClidTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
