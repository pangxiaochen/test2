import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-modal-more-test',
  templateUrl: './my-modal-more-test.component.html',
  styleUrls: ['./my-modal-more-test.component.css']
})
export class MyModalMoreTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
