import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyModalMoreTestComponent } from './my-modal-more-test.component';

describe('MyModalMoreTestComponent', () => {
  let component: MyModalMoreTestComponent;
  let fixture: ComponentFixture<MyModalMoreTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyModalMoreTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyModalMoreTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
