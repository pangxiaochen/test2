import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-video-panel',
  templateUrl: './video-panel.component.html',
  styleUrls: ['./video-panel.component.css']
})
export class VideoPanelComponent implements OnInit {
  tvData:any={
    "wheelPlanting":[],
    "menu":[]
  };
  constructor() { }

  ngOnInit() {
    this.tvData.wheelPlanting=[
      {"title":"少年包青天","describe":"大宋五年社会动荡，名不聊生......","path":"","imgPath":""}
    ]
    this.tvData.menu=[
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":0,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":1,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":2,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":3,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":4,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":5,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":6,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":7,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":8,"path":""},
      {"label":"奇葩说:马薇薇黄志忠抱头痛哭","pathIndex":9,"path":""}
    ]
  }
}
