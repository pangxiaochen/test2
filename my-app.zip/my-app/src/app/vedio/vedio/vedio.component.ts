import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vedio',
  templateUrl: './vedio.component.html',
  styleUrls: ['./vedio.component.css']
})
export class VedioComponent implements OnInit {
  moveList:any;
  total:Array<number>=new Array();
  constructor() { }

  ngOnInit() {
    this.moveList={
      "moveName":"少年张三丰",
      "label":"大宋五年，天下纷争，民不聊生，江湖嫌弃一阵血雨腥风一群以张三丰为代表的英雄好汉，除奸臣。。。",
      "total":25
    }
    for(let i=1;i<this.moveList.total;i++){
      this.total.push(i);
    }
    console.log(this.total)
  }

}
