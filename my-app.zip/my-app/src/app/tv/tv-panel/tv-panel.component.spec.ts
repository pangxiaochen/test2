import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TvPanelComponent } from './tv-panel.component';

describe('TvPanelComponent', () => {
  let component: TvPanelComponent;
  let fixture: ComponentFixture<TvPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TvPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TvPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
