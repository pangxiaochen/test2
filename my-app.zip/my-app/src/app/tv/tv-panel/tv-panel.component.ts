import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tv-panel',
  templateUrl: './tv-panel.component.html',
  styleUrls: ['./tv-panel.component.css']
})
export class TvPanelComponent implements OnInit {
  constructor(){}
  ngOnInit(){}

}
